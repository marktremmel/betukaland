/*
 * Shared bits for menu scenes: the current player, a scenic background,
 * and the HTML overlay used for the save-code and teacher screens
 * (real text fields, copy/paste and file pickers work best as HTML).
 */
BK.state = { profile: null };

BK.setProfile = function (p) {
  BK.state.profile = p;
  if (p) {
    BK.save.setLast(p.id); BK.audio.apply(p.settings);
    BK.setLayout(BK.layoutOf(p).id);
    // each child keeps the interface language they chose
    if (p.settings.ui) BK.applyUiLang(p.settings.ui, null);
    else { p.settings.ui = BK.uiLang; BK.save.persist(); }
    if (p.settings.font) BK.applyFont(p.settings.font, null);
    else { p.settings.font = BK.fontId; BK.save.persist(); }
  }
};

// Switch the font (Settings) and remember it, like the language
BK.applyFont = function (id, p) {
  if (!BK.FONTS.some(function (f) { return f.id === id; })) id = BK.FONTS[0].id;
  BK.fontId = id;
  var ov = document.getElementById('overlay'); if (ov) ov.style.fontFamily = BK.FONT;
  if (p) p.settings.font = id;
  BK.save.font(id);
};

// Switch the interface language and remember it (on this computer and, if given, for the child)
BK.applyUiLang = function (lang, p) {
  BK.setUiLang(lang);
  if (p) p.settings.ui = BK.uiLang;
  BK.save.uiLang(BK.uiLang);
};

// Sky + ground + a few trees; optional running bunny
BK.menuBackground = function (scene, sky, opts) {
  opts = opts || {};
  sky = sky || 1;
  // the child's own choice from the profile page (not on the Halloween page, which has its night)
  var mb = BK.state.profile && BK.state.profile.menuBg;
  if (mb && !opts.fixed && BK_MANIFEST.skies[mb]) sky = mb;
  var layers = BK_MANIFEST.skies[sky].length, out = { layers: [] };
  for (var i = 1; i <= layers; i++) {
    var t = scene.add.tileSprite(0, 0, BK.W, BK.H, 'sky' + sky + '_' + i).setOrigin(0, 0);
    t.tilePositionY = 50; t.speed = (i - 1) * 0.05;
    out.layers.push(t);
  }
  var gy = opts.groundY || 180;
  scene.add.image(60, gy + 1, 'tree').setOrigin(0.5, 1).setTint(0xa8c890);
  scene.add.image(330, gy + 1, 'tree').setOrigin(0.5, 1);
  scene.add.image(250, gy + 1, 'bush').setOrigin(0.5, 1);
  out.ground = scene.add.tileSprite(0, gy, BK.W, BK.H - gy, 'ground').setOrigin(0, 0);
  var tick = function (t, d) {
    out.layers.forEach(function (l) { l.tilePositionX += l.speed * d / 16; });
    if (opts.scroll) out.ground.tilePositionX += d / 16;
  };
  scene.events.on('update', tick);
  // scenes are reused: remove the listener when the screen closes, or they pile up
  scene.events.once('shutdown', function () { scene.events.off('update', tick); });
  return out;
};

// Profile picture: the chosen hero, standing, in its outfit
BK.avatarSprite = function (scene, x, y, idx, profile) {
  var h = BK.HEROES[idx] || BK.HEROES[0];
  var key = BK.outfitKey(h.idle, profile);
  var s = scene.add.sprite(x, y, key).setOrigin(0.5, 1);
  s.play(key);
  if (h.idle === h.run && !h.flies) { s.anims.pause(); s.setFrame(0); }
  s.setFlipX(BK.FACES_LEFT[h.id] === true);
  return s;
};

// ------------------------------------------------------------------ HTML overlay
BK.html = {
  el: function () { return document.getElementById('overlay'); },
  show: function (html) {
    var el = this.el();
    el.innerHTML = '<div class="ov-card">' + html + '</div>';
    el.style.display = 'flex';
    // the game underneath must not react to clicks on the dialog (Phaser listens on the whole window)
    if (window.BK_GAME) { BK_GAME.input.keyboard.enabled = false; BK_GAME.input.enabled = false; }
    if (!el.bkStop) {
      el.bkStop = true;
      ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'click'].forEach(function (t) {
        el.addEventListener(t, function (e) { e.stopPropagation(); });
      });
      // Esc closes the dialog like its Close / Back button
      window.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape' || el.style.display !== 'flex') return;
        var c = el.querySelector('#bk-close, #close, #cancel'); if (c) c.click();
      });
    }
    return el;
  },
  hide: function () {
    var el = this.el();
    el.style.display = 'none';
    el.innerHTML = '';
    if (window.BK_GAME) {
      BK_GAME.input.keyboard.enabled = true;
      // switch the mouse back on only after this click has finished travelling
      setTimeout(function () { BK_GAME.input.enabled = true; }, 120);
    }
  },
  esc: function (s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  },
};
